﻿using System;
using System.ComponentModel;

class Welcome1
{
    static void Main ()
    {

        oddoreven(Int32.Parse(Console.ReadLine()));
    
    }

    static void oddoreven(int input)
    {


            if (input % 2 == 0)
            {

                Console.WriteLine("This is an even number");

            }
            else if (input % 2 == 1)
            {
                Console.WriteLine("This is an odd number");
            }

            
       
        
    }
}
